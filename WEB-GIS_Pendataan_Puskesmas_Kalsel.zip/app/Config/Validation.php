<?php

namespace Config;

use CodeIgniter\Validation\CreditCardRules;
use CodeIgniter\Validation\FileRules;
use CodeIgniter\Validation\FormatRules;
use CodeIgniter\Validation\Rules;

class Validation
{
	//--------------------------------------------------------------------
	// Setup
	//--------------------------------------------------------------------

	/**
	 * Stores the classes that contain the
	 * rules that are available.
	 *
	 * @var string[]
	 */
	public $ruleSets = [
		Rules::class,
		FormatRules::class,
		FileRules::class,
		CreditCardRules::class,
	];

	/**
	 * Specifies the views that are used to display the
	 * errors.
	 *
	 * @var array<string, string>
	 */
	public $templates = [
		'list'   => 'CodeIgniter\Validation\Views\list',
		'single' => 'CodeIgniter\Validation\Views\single',
	];

	//autentikasi login
	public $login = [
		'username'	=> 'required',
		'pwd'	=> 'required'
	];

	public $login_errors = [
		'username'		=> [
			'required'		=> 'Username wajib diisi'
		],
		'pwd'			=> [
			'required'	=> 'Password wajib diisi'
		]
	];

	//autentikasi register
	public $register = [
		'username'		=> 'required',
		'pwd'			=> 'required',
		'nama_depan'	=> 'required',
		'nama_belakang'	=> 'required'
	];

	public $register_errors = [
		'username'		=> [
			'required'	=> 'Username wajib diisi'
		],
		'pwd'			=> [
			'required'	=> 'Password wajib diisi'
		],
		'nama_depan'	=> [
			'required'	=> 'Nama Depan wajib diisi'
		],
		'nama_belakang'	=> [
			'required'	=> 'Nama Belakang wajib diisi'
		]
	];

	//profil
	public $profil = [
		'username'		=> 'required',
		'nama_depan'	=> 'required'
	];

	public $profil_errors = [
		'username'		=> [
			'required'	=> 'Username wajib diisi'
		],
		'nama_depan'	=> [
			'required'	=> 'Nama Depan wajib diisi'
		]
	];

	//--------------------------------------------------------------------
	// Rules
	//--------------------------------------------------------------------
}
