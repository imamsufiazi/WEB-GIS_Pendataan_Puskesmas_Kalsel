<?php namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\M_User;
use App\Models\M_Login;

class DataUser extends BaseController
{
    protected $M_User;
    protected $M_Login;
    
    public function __construct()
    {
        $this->M_User = new M_User();
        $this->M_Login = new M_Login();
    }
    
    //halaman daftar user
	public function index()
	{
        //jika tidak ada session
        if(!session()->get('id_user'))
        {
            return redirect()->to(base_url('autentikasi/login'));
        }
        //jika ada session
        else
        {
            //jika role nya sesuai
            if(session()->get('role') == 'Admin')
            {
                $data = [
                    'title' => 'Riwayat Login & Data Pegawai',
                    'daftar_riwayat_user' => $this->M_Login->getLogin_semua_user(),
                    'daftar_riwayat_user_list' => $this->M_Login->getLogin_semua_user_list()
                ];
                return view('data_user/daftar', $data);
            }
            //jika role nya tidak sesuai
            else
            {
                return redirect()->to(base_url('dashboard'));
            }
        }
    }

    //halaman data riwayat login user
	public function data_user($id_user)
	{
        //jika tidak ada session
        if(!session()->get('id_user'))
        {
            return redirect()->to(base_url('autentikasi/login'));
        }
        //jika ada session
        else
        {
            //jika role nya sesuai
            if(session()->get('role') == 'Admin')
            {
                $datapegawai = $this->M_User->data_pegawai($id_user);
                foreach($datapegawai as $pegawai):
                    $data = [
                        'title' => 'Data Login - '.$pegawai->nama_depan.' '.$pegawai->nama_belakang,
                        'daftar_riwayat' => $this->M_Login->getLogin_user($id_user),
                        'hitung_login'  => $this->M_Login->cekLogin_user($id_user)
                    ];
                endforeach;
                return view('data_user/data', $data);
            }
            //jika role nya tidak sesuai
            else
            {
                return redirect()->to(base_url('dashboard'));
            }
        }
    }

    //halaman detail login user
    public function detail_user($id_login)
    {
        //jika tidak ada session
        if(!session()->get('id_user'))
        {
            return redirect()->to(base_url('autentikasi/login'));
        }
        //jika ada session
        else
        {
            //jika role nya sesuai
            if(session()->get('role') == 'Admin')
            {
                $detail_login = $this->M_Login->getLogin($id_login);
                foreach($detail_login as $detail_lgn):
                    $data = [
                        'title'             => 'Detail Login - '.$detail_lgn->nama_depan.' '.$detail_lgn->nama_belakang,
                        'tanggal_login'     => $detail_lgn->tanggal_login,
                        'latitude_login'    => $detail_lgn->latitude_login,
                        'longitude_login'   => $detail_lgn->longitude_login,
                        'nama_depan'        => $detail_lgn->nama_depan,
                        'nama_belakang'     => $detail_lgn->nama_belakang,
                        'id_user'           => $detail_lgn->id_user
                    ];
                endforeach;

                return view('data_user/detail', $data);
            }
            //jika role nya tidak sesuai
            else
            {
                return redirect()->to(base_url('dashboard'));
            }
        }
    }
}