<?php namespace App\Controllers;

use CodeIgniter\Controller;

class PendataanPuskesmas extends BaseController
{
    //halaman daftar pendataan puskesmas
	public function index()
	{
        //jika tidak ada session
        if(!session()->get('id_user'))
        {
            return redirect()->to(base_url('autentikasi/login'));
        }
        //jika ada session
        else
        {
            $data = [
                'title' => 'Pendataan Puskesmas',
            ];
            return view('pendataan_puskesmas', $data);
        }
    }
}