<div class="main-content" id="panel">
    <div class="container-fluid">
        <?= $this->renderSection('content'); ?>
    </div>
</div>