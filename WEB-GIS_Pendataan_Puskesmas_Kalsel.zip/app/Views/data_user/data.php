<?= $this->extend('_layout/layout_root'); ?>

<?= $this->section('header') ?>
    <!-- Header -->
    <div class="header bg-primary pb-6">
        <div class="container-fluid">
            <!-- judul halaman -->
            <div class="header-body">
                <div class="row py-4">
                    <div class="col-lg-12 col-12 text-center">
                        <h6 class="h2 text-white d-inline-block mb-0">
                            <?= $title; ?>
                        </h6>
                    </div>
                </div>
            </div>
            <!-- end judul halaman -->
        </div>
    </div>
    <!-- End Header -->
<?= $this->endSection(); ?>

<?= $this->section('content') ?>

    <div class="row">
        <div class="col-xl-12">
            <div class="card" style="min-height: 430px;">
                <div class="card-header">
                    <!-- button kembali -->
                    <nav class="navbar">
                        <div class="nav-item">
                            <!-- button kembali ke daftar riwayat login -->
                            <a class="btn btn-secondary" href="<?= base_url('admin/data-pegawai'); ?>"><i class="fa fa-arrow-left" aria-hidden="true"></i> Kembali</a>
                        </div>
                    </nav>
                    <!-- end button kembali -->
                </div>
                <div class="card-body">
                    <div class="text-center">
                    <ul class="nav nav-tabs" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" href="#map_data" role="tab" data-toggle="tab">Map Data</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#list_data" role="tab" data-toggle="tab">List Data</a>
                        </li>
                    </ul>
                    </div>

                    <!-- isi tab -->
                    <div class="tab-content">

                        <!-- tab maps -->
                        <div role="tabpanel" class="tab-pane in active" id="map_data">
                            <!-- tampilkan peta detail login user -->
                            <div style="width: 100%; height: 400px" id="mapRiwayatLoginUser"></div>
                        </div>

                        <!-- tab list -->
                        <div role="tabpanel" class="tab-pane fade" id="list_data">
                            <!-- table riwayat login -->
                            <div class="table-responsive">
                                <table id="pkr" class="table align-items-center table-flush table-hover">
                                    <thead class="thead-light">
                                        <tr class="text-center">
                                            <th>Tanggal Login</th>
                                            <th>Latitude Login</th>
                                            <th>Longitude Login</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach($daftar_riwayat as $rwyt): ?>
                                        <tr>
                                            <td><?= $rwyt->tanggal_login; ?></td>
                                            <td><?= $rwyt->latitude_login; ?></td>
                                            <td><?= $rwyt->longitude_login; ?></td>
                                            <td class="text-center" style="width: 100px;">
                                                <a class="btn btn-primary btn-sm" href="<?= base_url('admin/data-pegawai/detail/'.$rwyt->id_login); ?>"><i class="fa fa-info-circle" aria-hidden="true"></i> Detail</a>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- end table riwayat login -->
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

<?= $this->endSection(); ?>

<?= $this->section('javascript') ?>

    <script>
        //fungsi clustering maps
        function clustering(map) {
            // First we need to create an array of DataPoint objects,
            // for the ClusterProvider
            //data lokasi riwayat login
            var dataPoints = [];
                <?php foreach($daftar_riwayat as $rwyt): ?>
                    dataPoints.push(new H.clustering.DataPoint(<?= $rwyt->latitude_login; ?>, <?= $rwyt->longitude_login; ?>));
                <?php endforeach; ?>

            // Create a clustering provider with custom options for clusterizing the input
            var clusteredDataProvider = new H.clustering.Provider(dataPoints, {
                clusteringOptions: {
                    // Maximum radius of the neighbourhood
                    eps: 32,
                    // minimum weight of points required to form a cluster
                    minWeight: 2
                }
            });

            // Create a layer tha will consume objects from our clustering provider
            var layer = new H.map.layer.ObjectLayer(clusteredDataProvider);

            // To make objects from clustering provder visible,
            // we need to add our layer to the map
            map.addLayer(layer);
        }

        //Here Maps API key
        var platform = new H.service.Platform({
            'apikey': 'JL5l1bbfK5PNanfChbiiibjkvG6096jbHpzkfKtUwkM'
        });

        //tipe default dari layer maps
        var defaultLayers = platform.createDefaultLayers();

        //map pada halaman daftar login user
        var map = new H.Map(
            document.getElementById('mapRiwayatLoginUser'),
            defaultLayers.vector.normal.map,
            {
                zoom: 11,
                center: new H.geo.Point(-3.4625131999999996, 114.84486740000001)
            });
            //untuk meresize ukuran
            map.addEventListener('resize', () => map.getViewPort().resize())

        //UI, event dam behavior map
        var ui = H.ui.UI.createDefault(map, defaultLayers);
        var mapEvents = new H.mapevents.MapEvents(map);
        var behavior = new H.mapevents.Behavior(mapEvents);

        //panggil fungsi clustering
        clustering(map);
    </script>

<?= $this->endSection(); ?>