<?= $this->extend('_layout/layout_root'); ?>

<?= $this->section('header') ?>
    <!-- Header -->
    <div class="header bg-primary pb-6">
        <div class="container-fluid">
            <!-- judul halaman -->
            <div class="header-body">
                <div class="row py-4">
                    <div class="col-lg-12 col-12 text-center">
                        <h6 class="h2 text-white d-inline-block mb-0">
                            <?= $title; ?>
                        </h6>
                    </div>
                </div>
            </div>
            <!-- end judul halaman -->
        </div>
    </div>
    <!-- End Header -->
<?= $this->endSection(); ?>

<?= $this->section('content') ?>

    <div class="row">
        <div class="col-xl-12">
            <div class="card" style="min-height: 430px;">
                <div class="card-header">

                </div>
                <div class="card-body">
                        <!-- tab maps -->
                        <div role="tabpanel" class="tab-pane in active" id="map_data">
                            <!-- tampilkan peta detail login user -->
                            <div style="width: 100%; height: 400px" id="mapPendataanPuskesmas"></div>
                        </div>

                </div>
            </div>
        </div>
    </div>

<?= $this->endSection(); ?>

<?= $this->section('javascript') ?>

    <script>
        //fungsi untuk membaca geoJSON batas_admin_kalsel
        function geojson_kabkota(map){
            //inisiasi reader untuk membaca file geoJSON
            var reader = new H.data.geojson.Reader('<?= base_url('assets/geojson/batas_admin_kalsel.geojson') ?>');

            //mulai parsing file geoJSON
            reader.parse();

            //tambahkan layer diatas map
            map.addLayer(reader.getLayer());
            
            //fungsi untuk membaca posisi cursor mouse tap
            reader.getLayer().getProvider().addEventListener('tap', function(e) {
                //jika cursor mouse mentap didalam polygon dari geoJSON
                if(e.target instanceof H.map.Polygon) {
                    //inisiasi coord untuk melacak posisi latitude dan longitude dari posisi cursor
                    var coord = map.screenToGeo(e.currentPointer.viewportX, e.currentPointer.viewportY);
                    
                    //inisiasi posisi untuk mendapatkan posisi cursor mouse
                    var position = {lat: coord.lat, lng: coord.lng};
                    
                    //inisiasi bubble untuk menampilkan informasi nama kabupaten/kota dari daerah yg di tap oleh cursor map
                    var bubble = new H.ui.InfoBubble(position, {
                        //menampilkan konten datanya
                        content: '<b>'+e.target.getParentGroup().getData().properties.KABUPATEN+'</b>'
                    });
                    //hapus bubble jika telah tap lokasi lainnya
                    ui.getBubbles().forEach(bub => ui.removeBubble(bub));

                    //menambahkan bubblenya pada map
                    ui.addBubble(bubble);
                    //mencetak console log informasi tap dari cursor mouse
                    console.log(e.target.getParentGroup().getData().properties.KABUPATEN);

                    //pindah posisi map saat tap dari cursor mouser
                    map.setCenter(position, true);
                }
            });
        }

        //fungsi untuk membaca geoJSON puskesmas
        function geojson_puskesmas(map){
            //inisiasi reader untuk membaca file geoJSON
            var reader = new H.data.geojson.Reader('<?= base_url('assets/geojson/puskesmas.geojson') ?>');

            //mulai parsing file geoJSON
            reader.parse();

            //tambahkan layer diatas map
            map.addLayer(reader.getLayer());
            
            //fungsi untuk membaca posisi cursor mouse tap
            reader.getLayer().getProvider().addEventListener('tap', function(e) {
                //jika cursor mouse mentap didalam polygon dari geoJSON
                if(e.target instanceof H.map.Marker) {
                    //inisiasi coord untuk melacak posisi latitude dan longitude dari posisi cursor
                    var coord = map.screenToGeo(e.currentPointer.viewportX, e.currentPointer.viewportY);
                    
                    //inisiasi posisi untuk mendapatkan posisi cursor mouse
                    var position = {lat: coord.lat, lng: coord.lng};
                    
                    //inisiasi bubble untuk menampilkan informasi nama kabupaten/kota dari daerah yg di tap oleh cursor map
                    var bubble = new H.ui.InfoBubble(position, {
                        //menampilkan konten datanya
                        content: e.target.getParentGroup().getData().properties.NAMOBJ+'<br/><b>'+e.target.getParentGroup().getData().properties.KABUPATEN+'</b>'
                    });
                    //hapus bubble jika telah tap lokasi lainnya
                    ui.getBubbles().forEach(bub => ui.removeBubble(bub));

                    //menambahkan bubblenya pada map
                    ui.addBubble(bubble);
                    //mencetak console log informasi tap dari cursor mouse
                    console.log(e.target.getParentGroup().getData().properties.NAMOBJ)+' - '+e.target.getParentGroup().getData().properties.KABUPATEN;

                    //pindah posisi map saat tap dari cursor mouser
                    map.setCenter(position, true);
                }
            });
        }

        //inisiasi platform untuk passing APIKEY developer
        var platform = new H.service.Platform({
            'apikey': 'JL5l1bbfK5PNanfChbiiibjkvG6096jbHpzkfKtUwkM'
        });
        var defaultLayers = platform.createDefaultLayers();

        //inisiasi map
        var map = new H.Map(document.getElementById('mapPendataanPuskesmas'), defaultLayers.vector.normal.map, {
            zoom: 10,
            center: {lat:-3.4625131999999996, lng:114.84486740000001},
            pixelRatio: window.devicePixelRatio || 1
        });
        //tambahkan event listener untuk resize map
        window.addEventListener('resize', () => map.getViewPort().resize());

        //inisiasi behavior untuk mengimplementasikan interaksi pada map (pindah posisi map/zoom map)
        var behavior = new H.mapevents.Behavior(new H.mapevents.MapEvents(map));

        //inisiasi komponen UI
        var ui = H.ui.UI.createDefault(map, defaultLayers);

        //panggil fungsi geojson yang diaplikasikan pada map
        geojson_kabkota(map);
        geojson_puskesmas(map);
        
    </script>

<?= $this->endSection(); ?>